# MovieBox

学习用的电视端影视 App（仿影视仓的界面结构）。

## 阶段
1. 首页界面（当前）：标题、时钟、分类标签、功能按钮、海报墙，遥控器可操作
2. 详情页 + 播放器
3. 配置和接口层
4. 搜索、历史、收藏
5. 打磨

## 文件说明
- `app/src/main/java/com/alan/moviebox/MainActivity.java`：首页界面
- `app/src/main/java/com/alan/moviebox/Movie.java`：一部影片的数据
- `app/src/main/java/com/alan/moviebox/SampleData.java`：示例（假）数据
- `app/src/main/java/com/alan/moviebox/SettingsActivity.java`：设置页（二维码 + 接口列表）
- `app/src/main/java/com/alan/moviebox/ConfigServer.java`：电视上的小网页服务，手机扫码后在网页里添加 / 删除接口
- `app/src/main/java/com/alan/moviebox/SourceStore.java`：保存接口列表
- `app/src/main/assets/config.html`：手机上打开的网页
- `.github/workflows/build.yml`：在云端自动编译 APK

## 设置：扫码添加接口
首页右上角「设置」→ 手机和电视连同一个 Wi-Fi，用手机扫二维码 → 在网页里填接口地址。
二维码里带一次性口令，离开设置页或点「重新生成二维码」后旧码失效。
在电视上选中一个接口按「确定键」使用，长按「确定键」删除（连续长按两次）。

## 接口怎么读
- 支持 **type 1**（苹果CMS 的 JSON 接口，`.../api.php/provide/vod/` 这种）。
- 添加的地址可以是：接口本身、影视仓那种站点配置（`sites`）、或线路索引（`urls`）。
  选中后程序会自动识别：线路索引先选线路，再从里面选一个 type 1 的站点。
- type 3（要爬虫 jar / js 才能运行的站点）暂时不支持。
- 首页的「电影 / 剧集 / 综艺」标签，按接口返回的分类名字自动对应。
- 相关文件：`VodApi.java`（读取和解析）、`Net.java`（联网）、`Images.java`（海报图片）。

## 测试接口
`testapi/vod.json` 是一个格式和苹果CMS 一样的测试接口，里面是 Blender 基金会的开源短片。
上传到仓库后，在设置里添加下面这个地址就能测试：
`https://raw.githubusercontent.com/AlanChuaDev/Moviebox/main/testapi/vod.json`
